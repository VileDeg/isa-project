#ifndef __SERVER_H__
#define __SERVER_H__

void server_resolve_address(const char* server_domain_name, const char* server_port, char* server_ip);

#endif // !__SERVER_H__